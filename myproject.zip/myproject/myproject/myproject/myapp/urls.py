# myapp/urls.py
from django.contrib import admin
from django.urls import path
from .views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', login_view, name='login'),
    path('login', login_view, name='login'),
    path('regular', regular_user_view, name='regular_user_view'),
    path('admin_post/', admin_post, name='admin_post'),
    path('register', register, name='register'),  
    path('logout', logout_view, name='logout'),
    path('post', post, name='post'),
    
   
 path('send_message/<int:receiver_id>/', send_message, name='send_message'),
path('send_message', send_message, name='send_message'),  # Add this line




    path('inbox', inbox, name='inbox'),

    path('like/<int:post_id>/', like_post, name='like_post'),
    path('post_comment/<int:post_id>/', post_comment, name='post_comment'),
 
]