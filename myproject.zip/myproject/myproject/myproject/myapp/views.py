from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .forms import PostForm, CustomRegistrationForm
from django import forms
from django.contrib.auth import password_validation
from .models import Message
from .forms import MessageForm
from .models import Post, Comment
from .forms import PostForm, CommentForm

#user views
@login_required(login_url='login')
def regular_user_view(request):
    all_posts = Post.objects.all().order_by('-created_at') 
    comment_form = CommentForm()  # Add this line to create a comment form instance
    return render(request, 'user.html', {'posts': all_posts, 'comment_form': comment_form})



#admin
@login_required(login_url='login')
def admin_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = PostForm()

    posts = Post.objects.all().order_by('-created_at') 
   
    return render(request, 'admin.html', {'form': form, 'posts': posts})

#login
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if user.is_superuser:
                return redirect('admin_post')
            else:
                return redirect('regular_user_view')
        else:
            messages.error(request, 'Invalid login credentials.')

    return render(request, 'login.html')


class CustomRegistrationForm(forms.Form):
    username = forms.CharField(max_length=30)
    email = forms.EmailField()
    password1 = forms.CharField(widget=forms.PasswordInput)
    password2 = forms.CharField(widget=forms.PasswordInput)

from .forms import CustomRegistrationForm

from django.contrib.auth.models import User



#register
def register(request):
    if request.method == "POST":
        form = CustomRegistrationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password1']

            # Create a new user
            user = User.objects.create_user(username=username, email=email, password=password)

            messages.success(request, 'Your account has been successfully created.')
            return redirect('login')
    else:
        form = CustomRegistrationForm()

    return render(request, "register.html", {'form': form})




#logout
def logout_view(request):
    logout(request)
    return redirect('login')

#post
def post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user
            post.save()
            messages.success(request, 'Post successfully created.')
            return redirect('admin_post')
    else:
        form = PostForm()

    return render(request, 'admin.html', {'form': form})

#like
@login_required(login_url='login')
def like_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    user = request.user

    # Check if the user has already liked the post
    if user in post.likes.all():
        # If yes, unlike the post
        post.likes.remove(user)
    else:
        # If not, like the post
        post.likes.add(user)

    # Get the updated like count
    likes_count = post.likes.count()

    return JsonResponse({'likes': likes_count, 'liked': user in post.likes.all()})


#comments
@login_required(login_url='login')
def post_comment(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    if request.method == 'POST':
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.user = request.user
            comment.post = post
            comment.save()
            if request.user.is_superuser:
                return redirect('admin_post')
            else:
                return redirect('regular_user_view')

    else:
        comment_form = CommentForm()

    if request.user.is_superuser:
        template = 'admin.html'
    else:
        template = 'user.html'

    return render(request, template, {'post': post, 'comment_form': comment_form})

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .forms import MessageForm
from .models import Message

@login_required(login_url='login')
def send_message(request, receiver_id=None):
    if receiver_id is not None:
        receiver = get_object_or_404(User, pk=receiver_id)
    else:
        receiver = None
# views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .forms import MessageForm
from .models import Message

@login_required(login_url='login')
def send_message(request, receiver_id=None):
    if receiver_id is not None:
        recipient = get_object_or_404(User, pk=receiver_id)
    else:
        recipient = None

    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = request.user
            if recipient:
                message.receiver = recipient  # Set the receiver only when it's specified
            message.save()
            return redirect('send_message')  # Redirect to the user's sent messages page

    else:
        form = MessageForm()

    users = User.objects.exclude(id=request.user.id)  # Exclude the sender from the list
    sent_messages = Message.objects.filter(sender=request.user)
    received_messages = Message.objects.filter(receiver=request.user).order_by('-timestamp')
    
    return render(request, 'send_message.html', {'form': form, 'users': users, 'recipient': recipient, 'sent_messages': sent_messages, 'received_messages': received_messages})




@login_required(login_url='login')
def inbox(request):
    received_messages = Message.objects.filter(receiver=request.user).order_by('-timestamp')
    return render(request, 'inbox.html', {'received_messages': received_messages})
