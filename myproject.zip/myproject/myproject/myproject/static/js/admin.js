document.querySelectorAll('.like-button').forEach(button => {
    button.addEventListener('click', () => {
        const postId = button.dataset.postId;
        console.log('Post ID:', postId);

        const likeCount = button.nextElementSibling;
        console.log('Current Like Count:', likeCount.textContent);

        fetch(`/like/${postId}/`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Likes data:', data);
                likeCount.textContent = data.likes;
                button.classList.toggle('liked', data.liked);
            })
            .catch(error => {
                console.error('Error during fetch operation:', error);
            });
    });
});
